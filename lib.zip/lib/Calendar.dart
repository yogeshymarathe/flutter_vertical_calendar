import 'package:flutter/material.dart';

class CalendarChoose extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return CalendarChooseState();
  }
}

class CalendarChooseState extends State<CalendarChoose> {
  List weeks = ["M", "T", "W", "T", "F", "S", "S"];
  List days_in_month = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  List months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];
  List<List<DayMonthDetailModel>> daysOfMonth;
  final TRUE=1;
  final FALSE=0;
  int daycode;
  @override
  void initState() {
    super.initState();
    determineleapyear(2019);
    determinedaycode(2019);
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        appBar: AppBar(
          title: Text("Select Date"),
        ),
        body: Container(
          child: Column(
            children: <Widget>[
              Container(
                decoration:
                    BoxDecoration(color: Color(0xfffB8B8B8), boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10.0, // has the effect of softening the shadow
                    spreadRadius: 3.0, // has the effect of extending the shadow
                    offset: Offset(
                      3.0, // horizontal, move right 10
                      3.0, // vertical, move down 10
                    ),
                  )
                ]),
                height: 30,
                child: ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  itemExtent: MediaQuery.of(context).size.width / 7,
                  itemCount: weeks.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    return Container(
                        height: 30,
                        child: Center(
                            child: Text(
                          "${weeks[index]}",
                          style: TextStyle(color: Colors.white),
                        )));
                  },
                ),
              ),
              Expanded(
                child: ListView.separated(
                  itemCount: months.length,
                  itemBuilder: (context, index) {
                    return Container(
                      height: MediaQuery.of(context).size.height / 2.1,
                      child: Container(child: monthList(index)),
                    );
                  },
                  separatorBuilder: (BuildContext context, int index) {
                    return Divider();
                  },
                ),
              ),
            ],
          ),
        ));
  }

  void determinedaycode(int year) {
    int d1, d2, d3;

    d1 = ((year - 1) / 4.0).floor();
    d2 = ((year - 1) / 100).floor();
    d3 = ((year - 1) / 400).floor();
    daycode = (year + d1 - d2 + d3) % 7;
    print("mydaycode, $daycode");
  }

  Widget monthList(indexMonth) {
    daysOfMonth=calendarMonth(2019,indexMonth);
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(left: 18.0),
          child: Row(
            children: <Widget>[
              Text("${months[indexMonth]}",
                  style: TextStyle(
                      color: Colors.black54, fontWeight: FontWeight.bold)),
              SizedBox(
                width: 3,
              ),
              Text("2019",
                  style: TextStyle(
                      color: Colors.black54, fontWeight: FontWeight.bold))
            ],
          ),
        ),
        SizedBox(
          height: 5,
        ),
        Container(
          height: MediaQuery.of(context).size.height / 2.7,
          child: GridView.builder(
              physics: NeverScrollableScrollPhysics(),
              itemCount: daysOfMonth[indexMonth].length!=0?daysOfMonth[indexMonth].length:0,
              gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7),
              itemBuilder: (context, index) {
                return GestureDetector(
                    onTap: () {}, child: Center(child: Text("${daysOfMonth[indexMonth][index].day}")));
              }),
        ),
      ],
    );
  }



  int determineleapyear(int year)
  {
    if(year% 4 == FALSE && year%100 != FALSE || year%400 == FALSE)
    {
      days_in_month[2] = 29;
      return TRUE;
    }
    else
    {
      days_in_month[2] = 28;
      return FALSE;
    }
  }


  List<List<DayMonthDetailModel>> calendarMonth(int year,indexMonth) {
    List<List<DayMonthDetailModel>> listOfMonthData=List();
    List<DayMonthDetailModel> dmdmList = List();
    int month = indexMonth+1, day;
print("firstdayofmonth, $daycode");
    // Correct the position for the first date
    for (day = 0; day <= daycode; day++) {
//      printf(" ");
      DayMonthDetailModel localDMDM = DayMonthDetailModel();
      localDMDM.day = 0;
      localDMDM.month = 0;
      localDMDM.weekDay = "";
      dmdmList.add(localDMDM);
    }

    // Print all the dates for one month
    for (day = 1; day <= days_in_month[month]; day++) {
      DayMonthDetailModel localDMDM = DayMonthDetailModel();
//      print("perDay $day");
      localDMDM.day = day;
      dmdmList.add(localDMDM);
    }
    // Set position for next month
    daycode = (daycode + days_in_month[month]) % 7;
    print("perDay2, $daycode");
    listOfMonthData.add(dmdmList);
     return listOfMonthData;
  }
}

class DayMonthDetailModel {
  int day, month;
  String weekDay;
//  DayMonthDetails(this.day,this.weekDay);
}
